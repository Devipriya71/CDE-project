package com.productdetailsservice.model;

import java.io.Serializable;

import lombok.Data;



public @Data class ProductDetails implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8570631337245861257L;
	private String description;
	private String name;
	private Integer productQty;
	
	public ProductDetails(String description, String name, Integer productQty) {
		super();
		this.description = description;
		this.name = name;
		this.productQty = productQty;
	}
	
	
}

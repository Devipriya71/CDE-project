package com.productdetailsservice.constants;

public class Constants {
	
	 public static final String ProductUrl = "http://localhost:8003/product/productsearch/";
	 public static final String InventoryUrl = "http://localhost:8002/inventory/product/";
	 public static final String AddProductUrl = "http://localhost:8003/product/addproduct";
	 public static final String AddInventorytUrl = "http://localhost:8002/product/addproduct";
	 public static final String DeleteProductUrl = "http://localhost:8003/product/addproduct";
	 public static final String DeleteInventoryUrl = "http://localhost:8002/product/addproduct";
	 public static final String updateProductUrl = "http://localhost:8003/product/addproduct";
	 public static final String updateInventoryUrl = "http://localhost:8002/product/addproduct";
}

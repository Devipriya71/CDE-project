package com.inventoryservice.service.impl;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inventoryservice.model.InventoryEntity;
import com.inventoryservice.repository.Inventoryrepository;
import com.inventoryservice.service.Inventoryservice;

@Service
public class Inventoryserviceimpl implements Inventoryservice {

	@Autowired
	private Inventoryrepository inventoryrepository;
	
	public InventoryEntity getProduct( Integer productid) {
		
		Optional<InventoryEntity> productInventory =  inventoryrepository.findById(productid);
		return productInventory.get();
	}

	@Override
	public InventoryEntity addProductToInventory(InventoryEntity inventory) {
		// TODO Auto-generated method stub
		return inventoryrepository.save(inventory);
	}

	@Override
	public void deleteById(Integer prodId) {
		inventoryrepository.deleteById(prodId);
	}

	@Override
	public InventoryEntity updateProduct(InventoryEntity updatedInventory) {
		return inventoryrepository.save(updatedInventory);
	}
}



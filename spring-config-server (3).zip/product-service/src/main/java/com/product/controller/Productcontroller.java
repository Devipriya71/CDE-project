package com.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.product.exception.DataNotFoundException;
import com.product.model.Product;
import com.product.service.Productservice;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/product")
public class Productcontroller {
	
	@Autowired
	private Productservice productservice;
		
	@GetMapping("/productsearch/{name}")
	public ResponseEntity<?> getProductbyId(@PathVariable(value="name") String prodName) {
		List<Product> productList = productservice.getProduct(prodName);
		if(productList.size() > 0) {
			return new ResponseEntity<List<Product>>(productList, HttpStatus.OK);
		}else {
			throw new DataNotFoundException("No Product Found With Given Name");
		}
	}
	
	@PostMapping("/addproduct")
	public ResponseEntity<?> addProduct(@RequestBody Product product){
		Product savedProduct = productservice.addProduct(product);
		return new ResponseEntity<Product>(savedProduct, HttpStatus.CREATED);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> deleteProduct(@PathVariable("id") Integer prodId){
		productservice.deleteById(prodId);
		return new ResponseEntity<HttpStatus>(HttpStatus.OK);
	}
	
	@PutMapping("/update")
	public ResponseEntity<Product> updateProject(@RequestBody Product product){
		Product isAvailable = productservice.getProduct(product.getId());
		if(isAvailable == null) {
			throw new DataNotFoundException("No Product Found with given id");
		}else {
			Product updatedProduct = productservice.updateProduct(product);
			return new ResponseEntity<Product>(updatedProduct, HttpStatus.OK);
		}
	}
}

package com.demo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demo.model.Product;
import com.demo.service.Productservice;

@RestController
public class Productcontroller {
	
	@Autowired
	private Productservice productservice;
	
	// post method to insert product details
	
		@PostMapping("/product")
		public Product newProduct(@RequestBody Product newProduct) {
			Product item = productservice.addproduct(newProduct);
			return item;
		}
		
		// getById method
		
		@GetMapping("/product/{id}")
		public Product getProductbyId(@PathVariable(value="id") Integer itemId) {
			Optional<Product> item = productservice.getProduct(itemId);
			return item.get();
		}
	

}

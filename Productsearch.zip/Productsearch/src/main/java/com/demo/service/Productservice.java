package com.demo.service;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.demo.model.Product;
import com.demo.repository.Productrepository;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;


@Service
public class Productservice {
	@Autowired
	private Productrepository productrepository;
	
	//add new product
	
		public Product addproduct(Product item) {
			return productrepository.save(item);
			
		}
	
	//get product by id
	
		public Optional<Product> getProduct(@PathVariable Integer itemid) {
			return productrepository.findById(itemid);

}
}

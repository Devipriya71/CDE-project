package com.product.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.product.model.Product;
import com.product.service.Productservice;


@CrossOrigin(origins="*")
@RestController
public class Productcontroller {
	
	@Autowired
	private Productservice productservice;
	
	
	
		
		@GetMapping("/productsearch/{name}")
		public List<Product> getProductbyId(@PathVariable(value="name") String prodName) {
			return productservice.getProduct(prodName);
		}
	

}

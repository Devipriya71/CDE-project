package com.product.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.model.Product;
import com.product.repository.Productrepository;
import com.product.service.Productservice;


@Service
public class Productserviceimpl implements Productservice {
	
	@Autowired
	private Productrepository productrepository;
	public List<Product> getProduct(String prodName) {
		return productrepository.findByName(prodName);

}
	
	
	

}

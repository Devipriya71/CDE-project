package com.product.model;

import java.io.Serializable;

public class ProductDetails implements Serializable {
	private String description;
	private String name;
	private Integer productQty;
	
	public ProductDetails() {
		// TODO Auto-generated constructor stub
	}
	
	public ProductDetails(String description, String name, Integer productQty) {
		super();
		this.description = description;
		this.name = name;
		this.productQty = productQty;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getProductQty() {
		return productQty;
	}

	public void setProductQty(Integer productQty) {
		this.productQty = productQty;
	}
}

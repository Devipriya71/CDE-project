package com.product.Controller;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.product.Constants.Constants;
import com.product.model.Inventory;
import com.product.model.Product;
import com.product.model.ProductDetails;

@CrossOrigin
@RestController
@RequestMapping("/productDetailsService")
public class ProductDetailsController {
	
	@Autowired
	RestTemplate restTemplate;
	
	public ProductDetailsController() {
		
	}
	
	@GetMapping("/product/{name}")
	public List<ProductDetails> searchProduct(@PathVariable(value = "name") String prodName){
		ResponseEntity<Product[]> fetchedProducts = restTemplate.getForEntity(Constants.ProductUrl + prodName, Product[].class);
		Product[] products = fetchedProducts.getBody();
		return Arrays.asList(products).stream().map(product->{
			Inventory inventory = restTemplate.getForObject(Constants.InventoryUrl + product.getId(), Inventory.class);
			return new ProductDetails(product.getDescription(), product.getName(), inventory.getProductQty());
		}).collect(Collectors.toList());
	}

}

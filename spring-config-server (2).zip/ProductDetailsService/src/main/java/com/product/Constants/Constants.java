package com.product.Constants;

public class Constants {
	
	 public static final String ProductUrl = "http://localhost:8003/productsearch/";
	 public static final String InventoryUrl = "http://localhost:8002/product/";
}

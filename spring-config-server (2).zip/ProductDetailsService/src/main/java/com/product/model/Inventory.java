package com.product.model;

import java.io.Serializable;

public class Inventory implements Serializable{
	private Integer id;
	private Integer productQty;
	
	
	public Inventory(Integer prodId, Integer quantity) {
		super();
		this.id = prodId;
		this.productQty = quantity;
	}


	public Inventory() {
		// TODO Auto-generated constructor stub
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public Integer getProductQty() {
		return productQty;
	}


	public void setProductQty(Integer productQty) {
		this.productQty = productQty;
	}
}

package com.product.spring.config.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}

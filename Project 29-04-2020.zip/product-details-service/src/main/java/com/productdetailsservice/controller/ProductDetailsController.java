package com.productdetailsservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.productdetailsservice.exception.DataNotFoundException;
import com.productdetailsservice.model.ProductDetails;
import com.productdetailsservice.service.impl.ProductDetailsServiceService;

@RestController
@CrossOrigin("*")
@RequestMapping("/productDetailsService")
public class ProductDetailsController {
	
	@Autowired
	ProductDetailsServiceService productDetailsService;
	
	public ProductDetailsController() {
		
	}
	
	@GetMapping("/product/{name}")
	public List<ProductDetails> searchProduct(@PathVariable("name") String prodName) throws DataNotFoundException {
		
		return productDetailsService.searchProductService(prodName);
	}
}

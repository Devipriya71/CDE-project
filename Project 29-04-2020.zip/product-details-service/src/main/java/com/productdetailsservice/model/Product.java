package com.productdetailsservice.model;

import java.io.Serializable;

import lombok.Data;

public @Data class Product implements Serializable{
	
	private Integer id;
	private String name;
	private String description;	
}

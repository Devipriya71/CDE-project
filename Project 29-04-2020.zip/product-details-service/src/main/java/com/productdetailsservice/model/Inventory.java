package com.productdetailsservice.model;

import java.io.Serializable;

import lombok.Data;

public @Data class Inventory implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer id;
	private Integer productQty;
	
	
	
}

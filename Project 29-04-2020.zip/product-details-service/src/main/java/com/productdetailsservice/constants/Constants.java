package com.productdetailsservice.constants;

public class Constants {
	
	 public static final String ProductUrl = "http://localhost:8003/product/productsearch/";
	 public static final String InventoryUrl = "http://localhost:8002/inventory/product/";
}

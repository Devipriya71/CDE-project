package com.productdetailsservice.service;

import java.util.List;

import com.productdetailsservice.model.ProductDetails;

public interface IProductDetailsService {
	 
	public List<ProductDetails> searchProductService(String prodName);
}

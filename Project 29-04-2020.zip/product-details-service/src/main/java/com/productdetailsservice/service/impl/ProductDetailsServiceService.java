package com.productdetailsservice.service.impl;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.productdetailsservice.constants.Constants;
import com.productdetailsservice.exception.DataNotFoundException;
import com.productdetailsservice.model.Inventory;
import com.productdetailsservice.model.Product;
import com.productdetailsservice.model.ProductDetails;
import com.productdetailsservice.service.IProductDetailsService;

@Service
public class ProductDetailsServiceService implements IProductDetailsService{

	@Autowired
	RestTemplate restTemplate;
	public ProductDetailsServiceService() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<ProductDetails> searchProductService(String prodName) {
		try{
			ResponseEntity<Product[]> fetchedProducts = restTemplate.getForEntity(Constants.ProductUrl + prodName, Product[].class);
			Product[] products = fetchedProducts.getBody();
			if(products.length == 0) {
				throw new DataNotFoundException("No Such Product Exist"); 
			}
			return Arrays.asList(products).stream().map(product->{
				Inventory inventory = restTemplate.getForObject(Constants.InventoryUrl + product.getId(), Inventory.class);
				return new ProductDetails(product.getDescription(), product.getName(), inventory.getProductQty());
			}).collect(Collectors.toList());
		}catch (DataNotFoundException exception) {
			throw new DataNotFoundException("No Such Element Exist");
		}
	}
}

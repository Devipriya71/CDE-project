package com.product.exception;

public class ProductException {

	public ProductException() {
		// TODO Auto-generated constructor stub
	}

}

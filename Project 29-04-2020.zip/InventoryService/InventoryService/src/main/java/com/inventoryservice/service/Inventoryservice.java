package com.inventoryservice.service;

import java.util.Optional;
import com.inventoryservice.model.InventoryEntity;

public interface Inventoryservice {

	public Optional<InventoryEntity> getProduct( Integer productid);
}

package com.inventoryservice.exception;

public class InventoryException {

	public InventoryException() {
		// TODO Auto-generated constructor stub
	}

}

package com.inventoryservice.service.impl;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inventoryservice.model.InventoryEntity;
import com.inventoryservice.repository.Inventoryrepository;
import com.inventoryservice.service.Inventoryservice;

@Service
public class Inventoryserviceimpl implements Inventoryservice {

	@Autowired
	private Inventoryrepository inventoryrepository;
	
	public Optional<InventoryEntity> getProduct( Integer productid) {
		return inventoryrepository.findById(productid);
	}
}



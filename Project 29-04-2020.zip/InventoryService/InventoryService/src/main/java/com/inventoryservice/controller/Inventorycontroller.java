package com.inventoryservice.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.inventoryservice.model.InventoryEntity;
import com.inventoryservice.service.Inventoryservice;

@RestController
@RequestMapping("/inventory")
public class Inventorycontroller {
	
	@Autowired
	private Inventoryservice inventoryservice;
		
		@GetMapping("/product/{id}")
		public InventoryEntity getProductbyId(@PathVariable("id") Integer productId) {
			Optional<InventoryEntity> product = inventoryservice.getProduct(productId);
			return product.get();
		}

}

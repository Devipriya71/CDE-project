package com.product.constants;

public class Constants {

	public Constants() {
		// TODO Auto-generated constructor stub
	}

}

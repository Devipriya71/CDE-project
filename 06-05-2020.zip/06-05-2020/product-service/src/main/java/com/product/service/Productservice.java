package com.product.service;

import com.product.model.Product;
import java.util.List;


public interface Productservice {
	
	public List<Product> getProduct(String itemname);
	public Product addProduct(Product product);
	public void deleteById(Integer prodId);
	public Product updateProduct(Product product);
	public Product getProduct(Integer id);
}

package com.product.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.model.Product;
import com.product.repository.Productrepository;
import com.product.service.Productservice;


@Service
public class Productserviceimpl implements Productservice {
	
	@Autowired
	private Productrepository productrepository;

	@Override
	public List<Product> getProduct(String prodName) {
		return productrepository.findByName(prodName);
	}

	@Override
	public Product addProduct(Product product) {
		return productrepository.save(product);
	}

	@Override
	public void deleteById(Integer prodId) {
		productrepository.deleteById(prodId);
	}

	@Override
	public Product updateProduct(Product product) {
		return productrepository.save(product);
	}

	@Override
	public Product getProduct(Integer id) {
		return productrepository.getOne(id);
	}
}

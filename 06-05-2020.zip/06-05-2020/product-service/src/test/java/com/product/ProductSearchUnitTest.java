package com.product;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.product.model.Product;
import com.product.repository.Productrepository;
import com.product.service.Productservice;
import com.product.service.impl.Productserviceimpl;
@SpringBootTest(classes =ProductsearchApplication.class)
class ProductSearchUnitTest {

//	@Test
//	void test() {
//		fail("Not yet implemented");
//	}
	@InjectMocks
	Productserviceimpl productService;
	 @Mock
	    Productrepository productrep;
	
	@Test
	public void testGetProduct() {
		
		List<Product>  product = new ArrayList<>();
		  product.add( new Product(4,"laptop","hp"));
	Mockito
		.when(productrep.findByName("laptop"))
		.thenReturn(product);
	List<Product> retrievedProducts = productService.getProduct("laptop");
		assertEquals(1, retrievedProducts.size());
	}

}

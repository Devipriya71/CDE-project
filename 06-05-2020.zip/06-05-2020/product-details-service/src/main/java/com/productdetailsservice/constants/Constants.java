package com.productdetailsservice.constants;

public class Constants {
	
	 public static final String ProductUrl = "http://product-service/product/productsearch/";
	 public static final String InventoryUrl = "http://inventory-service/inventory/product/";
	 public static final String AddProductUrl = "http://product-service/product/addproduct";
	 public static final String AddInventorytUrl = "http://inventory-service/product/addproduct";
	 public static final String DeleteProductUrl = "http://product-service/product/addproduct";
	 public static final String DeleteInventoryUrl = "http://inventory-service/product/addproduct";
	 public static final String updateProductUrl = "http://product-service/product/addproduct";
	 public static final String updateInventoryUrl = "http://inventory-service/product/addproduct";
}

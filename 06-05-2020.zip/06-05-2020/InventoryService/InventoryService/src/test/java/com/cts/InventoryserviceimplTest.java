package com.cts;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.inventoryservice.model.InventoryEntity;
import com.inventoryservice.repository.Inventoryrepository;
import com.inventoryservice.service.impl.Inventoryserviceimpl;

@SpringBootTest
class InventoryserviceimplTest {

	
//	@Test
//	void test() {
//		fail("Not yet implemented");
//	}
	@InjectMocks
	Inventoryserviceimpl inventoryService;
	
	@Mock
	Inventoryrepository inventoryRepository;
	
	@BeforeAll
    public void init() {
        MockitoAnnotations.initMocks(this);
    }
	
	public void getProductTest() {
		
		InventoryEntity inventory = new InventoryEntity(1, 5);
		when(inventoryService.getProduct(1)).thenReturn(inventory);
		
		InventoryEntity retrievedInventory = inventoryService.getProduct(1);
		 assertEquals(inventory, retrievedInventory);
	}

}

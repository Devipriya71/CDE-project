package com.inventoryservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.inventoryservice.exception.DataNotFoundException;
import com.inventoryservice.model.InventoryEntity;
import com.inventoryservice.service.Inventoryservice;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/inventory")
public class Inventorycontroller {
	
	@Autowired
	private Inventoryservice inventoryservice;
		
	@GetMapping("/product/{id}")
	public ResponseEntity<?> getProductbyId(@PathVariable("id") Integer productId) {
		InventoryEntity product =inventoryservice.getProduct(productId);
		if(product == null) {
			throw new DataNotFoundException("No Product with given name found in Inventory");
		}
		return new ResponseEntity<InventoryEntity>(product, HttpStatus.OK);
	}
	
	@PostMapping("/addproduct")
	public ResponseEntity<?> addProduct(@RequestBody InventoryEntity inventory){
		InventoryEntity savedInventory = inventoryservice.addProductToInventory(inventory);
		return new ResponseEntity<InventoryEntity>(savedInventory, HttpStatus.CREATED);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> deleteProduct(@PathVariable("id") Integer prodId){
		inventoryservice.deleteById(prodId);
		return new ResponseEntity<HttpStatus>(HttpStatus.OK);
	}
	
	@PutMapping("/update")
	public ResponseEntity<?> updateProject(@RequestBody InventoryEntity updatedInventory){
		InventoryEntity isAvailable = inventoryservice.getProduct(updatedInventory.getId());
		if(isAvailable == null) {
			throw new DataNotFoundException("no such item found to delete");
		}
		InventoryEntity inventory = inventoryservice.updateProduct(updatedInventory);
		return new ResponseEntity<InventoryEntity>(inventory, HttpStatus.OK);
	}

}
